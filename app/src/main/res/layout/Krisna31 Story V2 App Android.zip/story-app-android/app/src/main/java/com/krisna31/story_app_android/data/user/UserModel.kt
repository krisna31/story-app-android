package com.krisna31.story_app_android.data.user

data class UserModel(
    val name: String,
    val apiToken: String,
)